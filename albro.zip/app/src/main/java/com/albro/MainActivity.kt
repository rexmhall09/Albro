package com.albro

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.GeckoRuntime

class MainActivity : Activity() {

    private lateinit var geckoView: GeckoView
    private lateinit var urlBar: EditText
    private lateinit var goButton: Button
    private lateinit var geckoSession: GeckoSession

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlBar = findViewById(R.id.url_bar)
        geckoView = findViewById(R.id.web_view)
        goButton = findViewById(R.id.go_button)

        // Initialize GeckoView and GeckoSession
        val geckoRuntime = GeckoRuntime.create(this)
        geckoSession = GeckoSession()
        geckoSession.open(geckoRuntime)
        geckoView.setSession(geckoSession)

        // Load a default page (Google in this case)
        geckoSession.loadUri("https://www.google.com")

        // Handle "Go" button click
        goButton.setOnClickListener {
            loadUrl()
        }

        // Optionally, handle the "Go" action on the keyboard (IME action)
        urlBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_GO) {
                loadUrl()
                true
            } else {
                false
            }
        }
    }

    private fun loadUrl() {
        var url = urlBar.text.toString()
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://$url"
        }
        geckoSession.loadUri(url)
    }

    override fun onBackPressed() {
        geckoSession.goBack()
    }
}
